# -*- coding: utf-8 -*-
#
# added reopen guide after selection and changed guides.ini to guide.cfg
# Copyright (C) 2015 Thomas Geppert [bluezed]
# bluezed.apps@gmail.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcgui
import xbmcaddon
import os
import json
import ConfigParser
import xml.etree.ElementTree as ET
import sqlite3 as lite
import sys

from fileFetcher import *
from strings import *
from operator import itemgetter

ADDON = xbmcaddon.Addon(id='plugin.program.mtvguide')
SOURCE_DB = 'source.db'
dex = 'dex'
reboot = 'reboot'
aftermathtv = 'aftermathtv'
ukturk = 'ukturk'
FTV = 'ftv'
uktvnow = 'uktvnow'
cluiptv = 'cluiptv'
suicide = 'suicide'
projectcypher = 'projectcypher'
notfilmon = 'filmnoton'
israelive = 'israelive'
adriansports = 'adriansports'
evolve = 'evolve'

dexAddon = 'plugin.video.dex'
rebootAddon = 'plugin.video.reboot'
aftermathtvAddon = 'plugin.video.aftermathtv'
ukturkAddon = 'plugin.video.ukturk'
FTVAddon = 'plugin.video.F.T.V'
uktvnowAddon = 'plugin.video.uktvnow'
cluiptvAddon = 'plugin.video.cluiptv'
suicideAddon = 'plugin.video.Suicide'
projectcypherAddon = 'plugin.video.ProjectCypher'
notfilmonAddon = 'plugin.video.notfilmon'
israeliveAddon = 'plugin.video.israelive'
adriansportsAddon = 'plugin.video.adriansports'
evolveAddon = 'plugin.video.Evolve'

#profilePath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
#if not os.path.exists(profilePath):
#    os.makedirs(profilePath)
#    self.databasePath = os.path.join(profilePath, Database.SOURCE_DB)


class GuideTypes(object):
    GUIDE_ID = 0
    GUIDE_SORT = 1
    GUIDE_NAME = 2
    GUIDE_FILE = 3
    GUIDE_DEFAULT = 4

    CUSTOM_FILE_ID = 6

    guideTypes = []
    guideParser = ConfigParser.ConfigParser()
    filePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.program.mtvguide', 'guide.cfg'))

    def __init__(self):
        try:
            fetcher = FileFetcher('guide.cfg', ADDON)
            if fetcher.fetchFile() < 0:
                xbmcgui.Dialog().ok(strings(FETCH_ERROR_TITLE), strings(FETCH_ERROR_LINE1), strings(FETCH_ERROR_LINE2))

            self.guideParser.read(self.filePath)
            guideTypes = []
            defaultGuideId = 0  # fallback to the first guide in case no default is actually set in the ini file
            for section in self.guideParser.sections():
                sectMap = self.SectionMap(section)
                id = int(sectMap['id'])
                fName = sectMap['file']
                sortOrder = int(sectMap['sort_order'])
                default = False
                if 'default' in sectMap and sectMap['default'] == 'true':
                    default = True
                    defaultGuideId = id
                guideTypes.append((id, sortOrder, section, fName, default))
            self.guideTypes = sorted(guideTypes, key=itemgetter(self.GUIDE_SORT))
            xbmc.log('[plugin.program.mtvguide] GuideTypes collected: %s' % str(self.guideTypes), xbmc.LOGDEBUG)

            if str(ADDON.getSetting('xmltv.type')) == '':
                ADDON.setSetting('xmltv.type', str(defaultGuideId))
        except:
            print 'unable to parse guide.cfg'

    def SectionMap(self, section):
        dict1 = {}
        options = self.guideParser.options(section)
        for option in options:
            try:
                dict1[option] = self.guideParser.get(section, option)
                if dict1[option] == -1:
                    xbmc.log('[plugin.program.mtvguide] skip: %s' % option, xbmc.LOGDEBUG)
            except:
                print("exception on %s!" % option)
                dict1[option] = None
        return dict1


    def getGuideDataItem(self, id, item):
        value = None
        guide = self.getGuideById(id)
        try:
            value = guide[item]
        except IndexError:
            xbmc.log('[plugin.program.mtvguide] DataItem with index %s not found' % item, xbmc.LOGDEBUG)
        return value


    def getGuideById(self, id):
        xbmc.log('[plugin.program.mtvguide] Finding Guide with ID: %s' % id, xbmc.LOGDEBUG)
        ret = []
        for guide in self.guideTypes:
            if guide[self.GUIDE_ID] == int(id):
                ret = guide
                xbmc.log('[plugin.program.mtvguide] Found Guide with data: %s' % str(guide), xbmc.LOGDEBUG)
        return ret


def getKodiVersion():
    # retrieve current installed version
    jsonQuery = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["version", "name"]}, "id": 1 }')
    jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
    jsonQuery = json.loads(jsonQuery)
    version = []
    if jsonQuery.has_key('result') and jsonQuery['result'].has_key('version'):
        version = jsonQuery['result']['version']
    return version['major']
    
def CheckHasThisAddon(FoundAddon):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % FoundAddon) == 1:
        return True
    else:
        return False 
    
def updatecategories(typeName):
    con = None
    profilePath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(profilePath):
        os.makedirs(profilePath)
    databasePath = os.path.join(profilePath, SOURCE_DB)
    
    if ADDON.getSetting('dexter.enabled') == 'true':
        if not CheckHasThisAddon(dexAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have DexterPro addon enabled but not installed...", "", "Please disable this addon in settings or install DexterPro!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('reboot.enabled') == 'true':
        if not CheckHasThisAddon(rebootAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have Reboot addon enabled but not installed...", "", "Please disable this addon in settings or install Reboot!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('aftermathtv.enabled') == 'true':
        if not CheckHasThisAddon(aftermathtvAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have AftermathTV addon enabled but not installed...", "", "Please disable this addon in settings or install AftermathTV!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('ukturk.enabled') == 'true':
        if not CheckHasThisAddon(ukturkAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have UK Turk addon enabled but not installed...", "", "Please disable this addon in settings or install UK Turk!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('FTV.enabled') == 'true':
        if not CheckHasThisAddon(FTVAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have F.T.V addon enabled but not installed...", "", "Please disable this addon in settings or install F.T.V!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('uktvnow.enabled') == 'true':
        if not CheckHasThisAddon(uktvnowAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have UKTV Again addon enabled but not installed...", "", "Please disable this addon in settings or install UKTV Again!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('cluiptv.enabled') == 'true':
        if not CheckHasThisAddon(cluiptvAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have Clu IPTV addon enabled but not installed...", "", "Please disable this addon in settings or install Clu IPTV!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('suicide.enabled') == 'true':
        if not CheckHasThisAddon(suicideAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have Suicide TV addon enabled but not installed...", "", "Please disable this addon in settings or install Suicide TV!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('projectcypher.enabled') == 'true':
        if not CheckHasThisAddon(projectcypherAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have Project Cypher addon enabled but not installed...", "", "Please disable this addon in settings or install Project Cypher!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('notfilmon.enabled') == 'true':
        if not CheckHasThisAddon(notfilmonAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have NotFilmOn addon enabled but not installed...", "", "Please disable this addon in settings or install NotFilmOn!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('israelive.enabled') == 'true':
        if not CheckHasThisAddon(israeliveAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have IsraeLIVE addon enabled but not installed...", "", "Please disable this addon in settings or install IsraeLIVE!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('adriansports.enabled') == 'true':
        if not CheckHasThisAddon(adriansportsAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have AdrianSports addon enabled but not installed...", "", "Please disable this addon in settings or install AdrianSports!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('evolve.enabled') == 'true':
        if not CheckHasThisAddon(evolveAddon):
            xbmcgui.Dialog().ok("Enabled addon not installed!", "You have Evolve addon enabled but not installed...", "", "Please disable this addon in settings or install Evolve!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            return
    if ADDON.getSetting('allfreeaddons.enabled') == 'true':
        TheseAddons   =  [ukturkAddon,FTVAddon,uktvnowAddon,cluiptvAddon,suicideAddon,projectcypherAddon,notfilmonAddon,israeliveAddon,adriansportsAddon,evolveAddon]
        for FoundAddon in TheseAddons:
            if not CheckHasThisAddon(FoundAddon):
                xbmcgui.Dialog().ok("Enabled addon not installed!", "All Free Addons enabled but " +FoundAddon+ " not installed...", "Please only enable addons you have installed or install " +FoundAddon+ "!")
                xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
                xbmc.sleep(350)
                ADDON.openSettings()
                return

    try:
        con = lite.connect(databasePath, detect_types=lite.PARSE_DECLTYPES)
            
        cur = con.cursor()
        cur.execute("UPDATE channels SET visible = 0")
        if ADDON.getSetting('dexter.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+dex+'%'])
            con.commit()
        if ADDON.getSetting('reboot.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+reboot+'%'])
            con.commit()
        if ADDON.getSetting('aftermathtv.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+aftermathtv+'%'])
            con.commit()
        if ADDON.getSetting('ukturk.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+ukturk+'%'])
            con.commit()
        if ADDON.getSetting('FTV.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+FTV+'%'])
            con.commit()
        if ADDON.getSetting('uktvnow.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+uktvnow+'%'])
            con.commit()
        if ADDON.getSetting('cluiptv.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+cluiptv+'%'])
            con.commit()
        if ADDON.getSetting('suicide.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+suicide+'%'])
            con.commit()
        if ADDON.getSetting('projectcypher.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+projectcypher+'%'])
            con.commit()
        if ADDON.getSetting('notfilmon.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+notfilmon+'%'])
            con.commit()
        if ADDON.getSetting('israelive.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+israelive+'%'])
            con.commit()
        if ADDON.getSetting('adriansports.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+adriansports+'%'])
            con.commit()
        if ADDON.getSetting('evolve.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%'+typeName+'%', '%'+evolve+'%'])
            con.commit()
        if ADDON.getSetting('allfreeaddons.enabled') == 'true':
            cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND (chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ?)",['%'+typeName+'%', '%'+ukturk+'%', '%'+FTV+'%', '%'+uktvnow+'%', '%'+cluiptv+'%', '%'+suicide+'%', '%'+projectcypher+'%', '%'+notfilmon+'%', '%'+israelive+'%', '%'+adriansports+'%', '%'+evolve+'%'])
            con.commit()
        if ADDON.getSetting('allfreeaddons.enabled') == 'false' and ADDON.getSetting('dexter.enabled') == 'false' and ADDON.getSetting('reboot.enabled') == 'false' and ADDON.getSetting('aftermathtv.enabled') == 'false' and ADDON.getSetting('ukturk.enabled') == 'false' and ADDON.getSetting('FTV.enabled') == 'false' and ADDON.getSetting('uktvnow.enabled') == 'false' and ADDON.getSetting('cluiptv.enabled') == 'false' and ADDON.getSetting('suicide.enabled') == 'false' and ADDON.getSetting('projectcypher.enabled') == 'false' and ADDON.getSetting('notfilmon.enabled') == 'false' and ADDON.getSetting('israelive.enabled') == 'false' and ADDON.getSetting('adriansports.enabled') == 'false' and ADDON.getSetting('evolve.enabled') == 'false':
            xbmcgui.Dialog().ok("No addons enabled!", "You have no addons enabled..", "", "Please go to addon settings and enable some addons for the guide to use!")
            xbmc.executebuiltin('XBMC.ActivateWindow(programs)')
            xbmc.sleep(350)
            ADDON.openSettings()
            if con:
                con.close()
            return
        ADDON.setSetting('last.category', typeName)
        cur.execute("SELECT id FROM channels WHERE visible = '1' LIMIT 1;")
        if not cur.fetchone():
            cur.execute("UPDATE channels SET visible = 0")
            if ADDON.getSetting('dexter.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+dex+'%'])
                con.commit()
            if ADDON.getSetting('reboot.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+reboot+'%'])
                con.commit()
            if ADDON.getSetting('aftermathtv.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+aftermathtv+'%'])
                con.commit()
            if ADDON.getSetting('ukturk.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+ukturk+'%'])
                con.commit()
            if ADDON.getSetting('FTV.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+FTV+'%'])
                con.commit()
            if ADDON.getSetting('uktvnow.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+uktvnow+'%'])
                con.commit()
            if ADDON.getSetting('cluiptv.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+cluiptv+'%'])
                con.commit()
            if ADDON.getSetting('suicide.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+suicide+'%'])
                con.commit()
            if ADDON.getSetting('projectcypher.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+projectcypher+'%'])
                con.commit()
            if ADDON.getSetting('notfilmon.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+notfilmon+'%'])
                con.commit()
            if ADDON.getSetting('israelive.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+israelive+'%'])
                con.commit()
            if ADDON.getSetting('adriansports.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+adriansports+'%'])
                con.commit()
            if ADDON.getSetting('evolve.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND chnaddon LIKE ?",['%All Channels%', '%'+evolve+'%'])
                con.commit()
            if ADDON.getSetting('allfreeaddons.enabled') == 'true':
                cur.execute("UPDATE channels SET visible = 1 WHERE chncategory LIKE ? AND (chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon LIKE ? OR chnaddon like ?)",['%All Channels%', '%'+ukturk+'%', '%'+FTV+'%', '%'+uktvnow+'%', '%'+cluiptv+'%', '%'+suicide+'%', '%'+projectcypher+'%', '%'+notfilmon+'%', '%'+israelive+'%', '%'+adriansports+'%', '%'+evolve+'%'])
                con.commit()
            xbmcgui.Dialog().ok("Error!", "Enabled addons have no channels under this category..", "", "Defaulting back to All Channels!")
            ADDON.setSetting('last.category', "All Channels")
        
    except lite.Error, e:
            
        print "Error %s:" % e.args[0]
        sys.exit(1)
            
    finally:
        if con:
            con.close()


if __name__ == '__main__':
    guideList = []
    gTypes = GuideTypes()
    for gType in gTypes.guideTypes:
        guideList.append(gType[gTypes.GUIDE_NAME])
    d = xbmcgui.Dialog()
    ret = d.select('Select channel category', guideList)
    if ret >= 0:
        guideId = gTypes.guideTypes[ret][gTypes.GUIDE_ID]
        typeId = str(guideId)
        typeName = gTypes.getGuideDataItem(guideId, gTypes.GUIDE_NAME)
        ver = getKodiVersion()
        if xbmc.getCondVisibility('system.platform.android') and int(ver) < 15:
            # This workaround is needed due to a Bug in the Kodi Android implementation
            # where setSetting() does not have any effect:
            #  #13913 - [android/python] addons can not save settings  [http://trac.kodi.tv/ticket/13913]
            xbmc.log('[plugin.program.mtvguide] Running on ANDROID with Kodi v%s --> using workaround!' % str(ver), xbmc.LOGDEBUG)
            filePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.program.mtvguide', 'settings.xml'))
            tree = ET.parse(filePath)
            root = tree.getroot()
            updated = False
            for item in root.findall('setting'):
                if item.attrib['id'] == '6':
                    if item.attrib['id'] == 'xmltv.type':
                        item.attrib['value'] = typeId
                        updated = True
                    elif item.attrib['id'] == 'xmltv.type_select':
                        item.attrib['value'] = typeName
                        updated = True
            if updated:
                tree.write(filePath)
                ADDON.openSettings()
        else:  # standard settings handling...
            if typeId == '6':
                ADDON.setSetting('xmltv.type', typeId)
                ADDON.setSetting('xmltv.type_select', typeName)
            else:
                updatecategories(typeName)

            # Custom
            #xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
            #xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
            import gui
            #self.close()
            #ADDON.openSettings(ADDON)
            xbmc.executebuiltin('XBMC.ActivateWindow(home)')
            xbmc.sleep(350)
            w = gui.TVGuide()
            w.doModal()
            xbmc.sleep(350)
            del w       