import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,base64
pipcan = base64.b64decode
PLUGIN=pipcan('cGx1Z2luLnZpZGVvLmNsdWlwdHY=')
reason = xbmcaddon.Addon(id=PLUGIN)
url44 = pipcan('aHR0cDovL3BpcHNwYW5lbC5uZXQvZnJlZS91c2VyLnBocA==')
r44 = requests.get(url44)
us = r44.content
def menu():
        menu2()

def menu2():
        url = pipcan('aHR0cDovLzE0OS41Ni4yNC44NDo4MS9wYW5lbF9hcGkucGhwP3VzZXJuYW1lPXBpcGNhbiZwYXNzd29yZD1waXBjYW4=')
        r = requests.get(url)
        match = re.compile('"name":"(.+?)","stream_id":"(.+?)"',re.DOTALL).findall(r.content)
        for name,url in set(match):
            bonding(name,pipcan('aHR0cDovLzE0OS41Ni4yNC44NDo4MS9saXZlL3BpcGNhbi9waXBjYW4v')+url+pipcan('Lm0zdTh8dXNlci1hZ2VudD0=')+us,4,'','','')
        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE )

def bonding(pillow,url,mode,iconimage,fanart,description):
        ok=True
        liz=xbmcgui.ListItem(pillow, iconImage=pipcan("RGVmYXVsdEZvbGRlci5wbmc="), thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": pillow, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        liz.addContextMenuItems(items=[], replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok
def showText(pillow,url):
    heading = pillow
    text = url
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text.replace('"','\n').replace('<strong>','[B]').replace('</strong>','[/B]').replace("'","").replace(",","").replace('<a href=','[COLOR yellow]').replace('</a>','[/COLOR]'))
            return
        except:
            pass
def hello(url):
        url2 = url
        play=xbmc.Player()
        try:
            play.play(url)  
        except: pass 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]  
        return param
def nosee(pillow,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&pillow="+urllib.quote_plus(pillow)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(pillow, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": pillow, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def grays(pillow,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&pillow="+urllib.quote_plus(pillow)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(pillow, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": pillow, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok            
params=get_params()
url=None
pillow=None
mode=None
iconimage=None
fanart=None
description=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        pillow=urllib.unquote_plus(params["pillow"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "pillow: "+str(pillow)

if mode==None or url==None or len(url)<1:
        print ""
        import time
        dialog = xbmcgui.Dialog()
        url = pipcan('aHR0cDovL3BpcHNwYW5lbC5uZXQvZnJlZS9jaGFubmVscy5waHA=')
        r = requests.get(url)
        dialog.ok('Message',r.content)
        time.sleep(2.0)
        menu2()
       
elif mode==1:
        menu()
elif mode==2:
        menu2()
elif mode==3:
        menu3(url)
elif mode==4:
        hello(url)
elif mode==5:
        showText(pillow,url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
